## REST API Specification for Plugins

### Collection: Plugins

**URI:** /plugins

**Methods:**

* **GET**: Retrieve a summarized list names of all UI Plugins

#### Examples
GET /plugins
[pluginA, pluginB, pluginC]
